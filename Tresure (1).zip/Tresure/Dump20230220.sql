CREATE DATABASE  IF NOT EXISTS `product` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `product`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: product
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `pack` varchar(45) NOT NULL,
  `max` varchar(45) NOT NULL,
  `purchase` varchar(45) NOT NULL,
  `sell` varchar(45) NOT NULL,
  `tax` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'iPhone','1','100000','90000','100000','2000'),(2,'HP Laptop','1','54000','52000','53500','1000'),(3,'Telephone','1','700','600','700','100'),(4,'Watch','1','1400','1200','1400','200'),(5,'Heater','2','750','750','750','100'),(6,'Washing Machine','1','20000','19000','20000','1500'),(7,'IronBox','2','2000','2300','2000','600'),(8,'Rice Cooker','1','1500','1200','14500','300'),(9,'Microwave','2','10000','9000','10000','500'),(10,'Hair Straightener','2','1500','1400','1500','200'),(11,'Sprite','10','800','580','700','100'),(12,'ThumsUp','10','800','700','750','80'),(13,'Mirinda','20','1500','1300','1500','200'),(14,'Limca','10','1000','800','950','100'),(15,'Fanta','10','1000','900','1000','80'),(16,'Frooti','10','1000','850','950','100'),(17,'7Up','20','1000','800','950','100'),(18,'Coco Cola','10','1000','800','950','100'),(19,'Mountain Dew','10','1000','800','950','100'),(20,'Pepsi','20','1000','900','1000','100'),(21,'Apples','10','200','150','200','20'),(22,'Strawberries','20','100','80','100','10'),(23,'Oranges','20','200','190','200','15'),(24,'PineApple','10','100','80','100','10'),(25,'WaterMelon','10','1000','800','950','50'),(26,'MuskMelon','10','500','400','500','10'),(27,'Promegranate','20','400','300','380','20'),(28,'Grapes','10kg','1000','900','980','20'),(29,'Blueberries','10kg','500','400','480','10'),(30,'JackFruit','5','2500','2000','2500','30'),(31,'Pens','30','90','80','90','10'),(32,'Pencils','10','50','40','50','5'),(33,'Eraser','10','20','18','20','2'),(34,'Sharpner','10','30','28','30','5'),(35,'RoughBook','20','600','480','580','20'),(36,'Classmate Notebook','10','1000','800','900','10'),(37,'Colourpencils','10','100','80','100','10'),(38,'Watercolours','20','200','180','200','5'),(39,'PosterColours','10','100','80','100','10'),(40,'Sketches','10','100','90','100','5'),(41,'Eclairs','100','200','180','200','10'),(42,'CoffeeBite','10','20','18','20','2'),(43,'Dairymilk','10','1000','800','1000','10'),(44,'Fivestar','10','100','80','100','5'),(45,'Lollipop','10','100','90','100','10'),(46,'Rasgulla','5kg','1000','800','1000','20'),(47,'KajuKatli','10kg','2000','1900','2000','20'),(48,'Mysorepak','5kg','1000','900','1000','10'),(49,'GulabJamun','10kg','2000','1950','2000','20'),(50,'Laddu','10kg','2000','1900','1980','15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'product'
--

--
-- Dumping routines for database 'product'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-20 16:11:42
